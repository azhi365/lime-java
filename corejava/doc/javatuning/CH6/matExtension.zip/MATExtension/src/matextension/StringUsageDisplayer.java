package matextension;

import java.text.NumberFormat;

import org.eclipse.mat.SnapshotException;
import org.eclipse.mat.snapshot.extension.IClassSpecificNameResolver;
import org.eclipse.mat.snapshot.extension.Subject;
import org.eclipse.mat.snapshot.model.IObject;
import org.eclipse.mat.snapshot.model.IPrimitiveArray;

@Subject("java.lang.String")
public class StringUsageDisplayer implements IClassSpecificNameResolver {

	public StringUsageDisplayer() {

	}

	@Override
	public String resolve(IObject object) throws SnapshotException {
		if (((IPrimitiveArray) object.resolveValue("value")) == null)
			return "";
		char[] v = (char[]) ((IPrimitiveArray) object.resolveValue("value"))
				.getValueArray();
		int count = (Integer) object.resolveValue("count");
		int offset = (Integer) object.resolveValue("offset");
		double re = (((double) count) / v.length);
		NumberFormat numberFormat = NumberFormat.getNumberInstance();
		return "value:" + new String(v, offset, count) + ",usage:"
				+ numberFormat.format(re);
	}
}
